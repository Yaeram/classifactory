# pylint: disable=invalid-name
"""Используется для sphinx и pkg_resources.resource_filename."""
__version__ = '1.0.0'
